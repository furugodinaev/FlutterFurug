import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../bloc/api_event.dart';
import '../bloc/api_state.dart';
import '../bloc/api_bloc.dart';
import '../data/ApiProvider.dart';
import '../data/Todo.dart';

class MyBlocPage extends StatefulWidget {
  MyBlocPage({Key? key}) : super(key: key);

  @override
  State<MyBlocPage> createState() => _MyBlocPageState();
}

class _MyBlocPageState extends State<MyBlocPage> {
  bool change = true;
  List<User> users = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("ToDo List"),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          context.read<ApiBloc>().add(ToDoEventGet());
        },
        child: Icon(Icons.add_box_outlined),
      ),
      body: buildBloc(),
    );
  }

  /**  --------------- Focus Here  ----------------------- **/
  Widget buildBloc() {
    return BlocBuilder<ApiBloc, ApiState>(builder: (context, state){
      if (state is InitialState){
        return buildInitialView();
      }
      if (state is Loading) {
        return Center(
          child: CircularProgressIndicator(),
        );
      }
      if (state is SuccessToDo){
        List<ToDo> todoList = state.todoList;
        return buildToDoList(todoList);
      }
      if(state is Failure){
        return Text("Error");
      }
      return Text("NTH");
    });
  }
  /** 
   --------------- Focus Here  -----------------------
     **/

  Widget buildUserList(List<User> users) {
    return ListView.builder(
        itemCount: users.length,
        itemBuilder: (BuildContext context, int index) {
          return ListTile(
            leading: Icon(Icons.person),
            title: Text("${users[index].name}"),
            subtitle: Text("${users[index].email}"),
          );
        });
  }

  Widget buildInitialView() {
    return Center(
      child: ElevatedButton(onPressed: (){
        context.read<ApiBloc>().add(ToDoEventGet());
      },child: Text("ToDoList"),),
    );
  }
  Widget buildToDoList(List<ToDo> todoList){
    return ListView.builder(
        itemCount: todoList.length,
        itemBuilder: (BuildContext context, int index) {
          return ListTile(
            leading: Icon(Icons.person),
            title: Text("${todoList[index].title}"),
            trailing: Icon(todoList[index].competed ?
            Icons.check_circle : Icons.check_box_outline_blank_rounded));
        });
  }
}
