class ToDo {
  late int id;
  late int userId;
  late String title;
  late bool competed;

  ToDo.fromJson(Map<String, dynamic> json)
  {
    id = json['id'];
    userId = json['userId'];
    title = json['title'];
    competed = json['completed'];
  }
}
