
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../bloc/api_event.dart';
import '../bloc/api_state.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../data/Todo.dart';


class ApiBloc extends Bloc<ApiEvent, ApiState> {
  ApiBloc() : super(InitialState()) {
    on<ToDoEventGet>(_toDoEventGet);
  }

  _toDoEventGet(ToDoEventGet event, Emitter<ApiState> emitter) async
  {
    try {
      emitter(Loading());
      List<ToDo> todoList = await getToDo();
      emitter(SuccessToDo(todoList));
    } catch (e) {
      emitter(Failure());
    }
  }

  Future<List<ToDo>> getToDo() async {
    List<ToDo> todoList = [];
    var response = await http.get(Uri.parse('https://jsonplaceholder.typicode.com/todos'));
    if (response.statusCode == 200) {
      final body = json.decode(response.body) as List;
      body.forEach((json) {
        todoList.add(ToDo.fromJson(json));
      });
      return todoList;
    }
    else{
      print('Error');
    }
    return [];
  }
}
