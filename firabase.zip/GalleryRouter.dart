import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:lab6_firabase/Gallery.dart';

class GalleryRouter extends StatelessWidget {
  final Gallery gallery;

  GalleryRouter(this.gallery, {Key? key}) : super(key: key);

  static PageRouteBuilder getRoute(Gallery gallery) {
    return PageRouteBuilder(
        transitionsBuilder: (_, animation, secondAnimation, child) {
          return FadeTransition(
            opacity: animation,
            child: RotationTransition(
              turns: Tween<double>(begin: 0.5, end: 1.0).animate(animation),
              child: child,
            ),
          );
        }, pageBuilder: (_, __, ___) {
      return new GalleryRouter(gallery);
    });
  }

  @override
  Widget build(BuildContext context) {
    updateViews();
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text(gallery.title),
      ),
      body: Center(child: Image.network(gallery.image)),
    );
  }

  void updateViews() {
    FirebaseFirestore.instance
        .collection('gallery')
        .doc(gallery.docId)
        .update({'views': FieldValue.increment(1)})
        .then((value) => print("Gallery Updated"))
        .catchError((error) => print("Failed to update gallery: $error"));
  }
}