import 'package:cloud_firestore/cloud_firestore.dart';

class Gallery {
  late String title;
  late String image;
  late int views;
  late String docId;

  Gallery.fromDoc(QueryDocumentSnapshot doc) {
    title = doc["title"];
    image = doc["image"];
    views = doc["views"];
    docId = doc.id;
  }
}